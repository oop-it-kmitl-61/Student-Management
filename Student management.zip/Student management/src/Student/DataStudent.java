/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student;

import Admin.*;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Ratana Koon
 */
public class DataStudent {
    public static Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/schooldatabase?zeroDateTimeBehavior=convertToNull";
			String user = "root";
			String pwd;
                        pwd = "";
			con = DriverManager.getConnection(url,user,pwd);	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
    
    public static String getPWID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(2);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(1);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataFName(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(3);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataLName(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(4);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataCitizenID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(5);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataSex(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(6);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataAddress(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(7);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataMobilePhone(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(8);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getDataBirth(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(9);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getClass(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from student where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(10);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    /*public void Data(String ID, String Password, String FName, String LName, String CitizenID, String DateOfBirth, String Sex, String Address, String MobilePhone, String Class){

    
    }*/
    
    
    
    
    
    

    void exit(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
