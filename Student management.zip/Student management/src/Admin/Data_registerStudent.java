/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import static Admin.Data_register.getCon;
import java.sql.*;

/**
 *
 * @author Ratana Koon
 */
public class Data_registerStudent {
    public static Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/schooldatabase?zeroDateTimeBehavior=convertToNull";
			String user = "root";
			String pwd;
                        pwd = "";
			con = DriverManager.getConnection(url,user,pwd);	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
    
    public static String getDataID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from login where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(1);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    
    
   public static void insertData(int ID, String Password, String FName, String LName, String CitizenID, String DateOfBirth, String Sex, String Address, String MobilePhone, String Class) {
		try {
			String sqlCmd = "INSERT INTO schooldatabase.student value (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			statement.setInt(1, ID);
			statement.setString(2, Password);
			statement.setString(3, FName);
			statement.setString(4, LName);
                        statement.setString(5, CitizenID);
			statement.setString(6, Sex);
			statement.setString(7, Address);
                        statement.setString(8, MobilePhone);
                        statement.setString(9, DateOfBirth);
                        statement.setString(10, Class);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

    void exit(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
