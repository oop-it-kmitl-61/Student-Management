/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.sql.*;

/**
 *
 * @author Ratana Koon
 */
public class Data_register {
    public static Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/schooldatabase?zeroDateTimeBehavior=convertToNull";
			String user = "root";
			String pwd;
                        pwd = "";
			con = DriverManager.getConnection(url,user,pwd);	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
    
    public static String getDataID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from teacher where teacher_id = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(3);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    
    
    
    
    
    public static void insertData(String ID, String Password, String FName, String LName, String CitizenID, String Sex, String Address, String MobilePhone, String DateOfBirth, String Class) {
		try {
			String sqlCmd = "INSERT INTO schooldatabase.student value (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			statement.setString(1, ID);
			statement.setString(2, Password);
			statement.setString(3, FName);
			statement.setString(4, LName);
                        statement.setString(5, CitizenID);
			statement.setString(6, Sex);
			statement.setString(7, Address);
                        statement.setString(8, MobilePhone);
                        statement.setString(9, DateOfBirth);
                        statement.setString(10, Class);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public static void insertData3_1(int ID, int Score_math, int Score_thai, int Score_Eng, int Score_sci, String fname, String lname) {
		try {
			String sqlCmd = "INSERT INTO schooldatabase.class3_1 value (?,?,?,?,?,?,?)";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			statement.setInt(1, ID);
			statement.setInt(2, Score_math);
			statement.setInt(3, Score_thai);
			statement.setInt(4, Score_Eng);
                        statement.setInt(5, Score_sci);
                        statement.setString(6, fname);
                        statement.setString(7, lname);
                        
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public static void insertData3_2(int ID, int Score_math, int Score_thai, int Score_Eng, int Score_sci, String fname, String lname) {
		try {
			String sqlCmd = "INSERT INTO schooldatabase.class3_2 value (?,?,?,?,?,?,?)";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			statement.setInt(1, ID);
			statement.setInt(2, Score_math);
			statement.setInt(3, Score_thai);
			statement.setInt(4, Score_Eng);
                        statement.setInt(5, Score_sci);
                        statement.setString(6, fname);
                        statement.setString(7, lname);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public static void insertData3_3(int ID, int Score_math, int Score_thai, int Score_Eng, int Score_sci, String fname, String lname) {
		try {
			String sqlCmd = "INSERT INTO schooldatabase.class3_3 value (?,?,?,?,?,?,?)";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			statement.setInt(1, ID);
			statement.setInt(2, Score_math);
			statement.setInt(3, Score_thai);
			statement.setInt(4, Score_Eng);
                        statement.setInt(5, Score_sci);
                        statement.setString(6, fname);
                        statement.setString(7, lname);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public static String getTeacherFName(String sub) {
		String result = null;
		try {
                        String sqlCmd = "select fname from teacher where subject = '"+sub+"'";
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(1);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getTeacherLName(String sub) {
		String result = null;
		try {
                        String sqlCmd = "select lname from teacher where subject = '" + sub+ "'";;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(1);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getScore(String ID, String Class, String sub) {
		String result = null;
		try {
                        String sqlCmd = "select Score_"+sub+" from class"+Class+" where ID = "+ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(1);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    public static String getGrade(String score) {
        String grade = null;
		if(Integer.parseInt(score) >= 80){
                    grade = "A";
                }else if(Integer.parseInt(score) >= 75 && Integer.parseInt(score) < 80){
                    grade = "B+";
                }else if(Integer.parseInt(score) >= 70 && Integer.parseInt(score) < 75){
                    grade = "B";
                }else if(Integer.parseInt(score) >= 65 && Integer.parseInt(score) < 70){
                    grade = "C+";
                }else if(Integer.parseInt(score) >= 60 && Integer.parseInt(score) < 65){
                    grade = "C";
                }else if(Integer.parseInt(score) >= 55 && Integer.parseInt(score) < 60){
                    grade = "D+";
                }else if(Integer.parseInt(score) >= 50 && Integer.parseInt(score) < 55){
                    grade = "D";
                }else{
                    grade = "F";
                }
                return grade;
	}
    
    public static String getPWID(String ID) {
		String result = null;
		try {
                        String sqlCmd = "select * from login where ID = " + ID;
			PreparedStatement statement = getCon().prepareStatement(sqlCmd);
			ResultSet rs = statement.executeQuery(sqlCmd);
			rs.next();
			result = rs.getString(2);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
    
    
   


    void exit(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
